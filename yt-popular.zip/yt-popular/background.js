const ID = "UC[A-Za-z0-9_-]{22}";

function scrapeChannelId() {
  const ID = "UC[A-Za-z0-9_-]{22}";

  const fromPath = location.pathname.match(new RegExp(`/channel/(${ID})`));
  if (fromPath) return fromPath[1];

  const meta = document.querySelector('meta[itemprop="identifier"]');
  if (meta && new RegExp(`^${ID}$`).test(meta.content)) return meta.content;

  const canonical = document.querySelector('link[rel="canonical"]');
  const fromCanonical = canonical?.href.match(new RegExp(`/channel/(${ID})`));
  return fromCanonical ? fromCanonical[1] : null;
}

function isChannelPage(url) {
  try {
    const u = new URL(url);
    return /(^|\.)youtube\.com$/.test(u.hostname) &&
           /^\/(channel\/|c\/|user\/|@)/.test(u.pathname);
  } catch {
    return false;
  }
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !isChannelPage(tab.url ?? "")) return;

  const [injection] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scrapeChannelId
  });

  const channelId = injection?.result;
  console.log("[popular] channel id:", channelId, "on", tab.url);
  if (!channelId) return;

  chrome.tabs.update(tab.id, {
    url: `https://www.youtube.com/playlist?list=UULP${channelId.slice(2)}`
  });
});